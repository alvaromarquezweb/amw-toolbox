<?php
/**
 * AMW Toolbox — Cleanup: every tweak, each one gated behind its own option.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$o = amw_toolbox_get_options();


/* ═══════════════════════════════════════════════════════════════════════════
   1. ADMIN AREA — hide selected items
   ═══════════════════════════════════════════════════════════════════════════ */

// Hide the chosen top-level admin menu items.
if ( ! empty( $o['hidden_menus'] ) ) {
	$amw_hidden_menus = $o['hidden_menus'];

	add_action( 'admin_menu', function () use ( $amw_hidden_menus ) {
		foreach ( $amw_hidden_menus as $slug ) {
			remove_menu_page( $slug );
		}
	}, 9999 );
}

// Hide the chosen admin bar nodes.
if ( ! empty( $o['hidden_adminbar'] ) ) {
	$amw_hidden_adminbar = $o['hidden_adminbar'];

	add_action( 'wp_before_admin_bar_render', function () use ( $amw_hidden_adminbar ) {
		global $wp_admin_bar;

		foreach ( $amw_hidden_adminbar as $node ) {
			$wp_admin_bar->remove_node( $node );
		}
	} );
}

// Hide the chosen dashboard widgets.
if ( ! empty( $o['hidden_dashboard'] ) ) {
	$amw_hidden_dashboard = $o['hidden_dashboard'];

	add_action( 'wp_dashboard_setup', function () use ( $amw_hidden_dashboard ) {
		$map = amw_toolbox_dashboard_widgets();

		foreach ( $amw_hidden_dashboard as $id ) {
			$context = isset( $map[ $id ][1] ) ? $map[ $id ][1] : 'normal';
			remove_meta_box( $id, 'dashboard', $context );
		}
	} );
}


/* ═══════════════════════════════════════════════════════════════════════════
   2. DISABLE COMMENTS
   ═══════════════════════════════════════════════════════════════════════════ */

if ( $o['disable_comments'] ) {

	add_action( 'admin_init', function () {
		global $pagenow;

		// Redirect any attempt to open the comments screen.
		if ( 'edit-comments.php' === $pagenow ) {
			wp_safe_redirect( admin_url() );
			exit;
		}

		// Remove comment and ping support from every post type.
		foreach ( get_post_types() as $type ) {
			if ( post_type_supports( $type, 'comments' ) ) {
				remove_post_type_support( $type, 'comments' );
				remove_post_type_support( $type, 'trackbacks' );
			}
		}
	} );

	// Remove the "Comments" item from the admin menu.
	add_action( 'admin_menu', function () {
		remove_menu_page( 'edit-comments.php' );
	} );

	// Close comments and pings on the front end and hide existing ones.
	add_filter( 'comments_open',  '__return_false',      20, 2 );
	add_filter( 'pings_open',     '__return_false',      20, 2 );
	add_filter( 'comments_array', '__return_empty_array', 10, 2 );
}


/* ═══════════════════════════════════════════════════════════════════════════
   3. HEAD & HTTP HEADER CLEANUP / HARDENING
   ═══════════════════════════════════════════════════════════════════════════ */

// Hide the WordPress version from the <head>, RSS feeds and HTTP headers.
if ( $o['hide_wp_version'] ) {
	add_filter( 'the_generator', '__return_empty_string' );
	remove_action( 'wp_head', 'wp_generator' );
}

// Remove the X-Powered-By header (PHP fingerprint). More reliable than unset()
// on wp_headers, because this header is added by PHP, not by WordPress.
if ( $o['remove_powered_by'] ) {
	add_action( 'send_headers', function () {
		if ( ! headers_sent() ) {
			header_remove( 'X-Powered-By' );
		}
	} );
}

// Basic security headers, each toggled independently.
if ( $o['header_nosniff'] || $o['header_frame'] || $o['header_referrer'] ) {
	add_action( 'send_headers', function () use ( $o ) {
		if ( headers_sent() ) {
			return;
		}
		if ( $o['header_nosniff'] ) {
			header( 'X-Content-Type-Options: nosniff' );
		}
		if ( $o['header_frame'] ) {
			header( 'X-Frame-Options: SAMEORIGIN' );
		}
		if ( $o['header_referrer'] ) {
			header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		}
	} );
}

// Remove unnecessary tags that WordPress adds to the <head> by default.
if ( $o['clean_head_tags'] ) {
	remove_action( 'wp_head', 'rsd_link' );                            // RSD
	remove_action( 'wp_head', 'wlwmanifest_link' );                    // Windows Live Writer
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );                // Shortlink
	remove_action( 'wp_head', 'feed_links', 2 );                       // Feeds (posts)
	remove_action( 'wp_head', 'feed_links_extra', 3 );                 // Feeds (extra)
	remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 ); // Prev/Next
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );     // Emoji JS
	remove_action( 'wp_print_styles', 'print_emoji_styles' );          // Emoji CSS
}


/* ═══════════════════════════════════════════════════════════════════════════
   4. SECURITY & PERFORMANCE
   ═══════════════════════════════════════════════════════════════════════════ */

// Disable XML-RPC (a common attack vector).
if ( $o['disable_xmlrpc'] ) {
	add_filter( 'xmlrpc_enabled', '__return_false' );
}

// Prevent editing themes and plugins from the admin area.
if ( $o['disallow_file_edit'] && ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

// Heartbeat API mode: leave as default, slow down (~60s), or disable completely.
// Disabling also turns off autosave and post locking while editing.
if ( 'off' === $o['heartbeat_mode'] ) {
	add_action( 'init', function () {
		wp_deregister_script( 'heartbeat' );
	}, 1 );
} elseif ( 'slow' === $o['heartbeat_mode'] ) {
	add_filter( 'heartbeat_settings', function ( $settings ) {
		$settings['interval'] = 60;
		return $settings;
	} );
}

// Post revisions: cap or disable how many WordPress keeps from now on.
// Defined early here; skipped if wp-config.php already sets the constant.
if ( ! defined( 'WP_POST_REVISIONS' ) ) {
	if ( 'disable' === $o['revisions_mode'] ) {
		define( 'WP_POST_REVISIONS', false );
	} elseif ( 'limit' === $o['revisions_mode'] ) {
		define( 'WP_POST_REVISIONS', max( 0, (int) $o['revisions_limit'] ) );
	}
}

// Remove the front-end block editor (Gutenberg) CSS. Handy on Divi sites that
// don't render core blocks on the front.
if ( $o['remove_block_css'] ) {
	add_action( 'wp_enqueue_scripts', function () {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
		wp_dequeue_style( 'global-styles' );
		wp_dequeue_style( 'classic-theme-styles' );
	}, 100 );
}

// Disable oEmbed: drop the discovery links, stop auto-discovery and remove the
// front-end wp-embed.js.
if ( $o['disable_oembed'] ) {
	add_action( 'init', function () {
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'wp_head', 'wp_oembed_add_host_js' );
		add_filter( 'embed_oembed_discover', '__return_false' );
	}, 9999 );

	add_action( 'wp_footer', function () {
		wp_deregister_script( 'wp-embed' );
	} );
}

// Strip the version query string (?ver=) from scripts and styles.
// Note: that "?ver" acts as a cache-buster; removing it means some browsers
// may serve a cached copy of the file after a plugin update.
if ( $o['strip_version_query'] ) {
	add_action( 'init', function () {
		if ( ! is_admin() ) {
			add_filter( 'script_loader_src', 'amw_toolbox_strip_version_query', 15 );
			add_filter( 'style_loader_src',  'amw_toolbox_strip_version_query', 15 );
		}
	} );
}

function amw_toolbox_strip_version_query( $src ) {
	return $src ? remove_query_arg( 'ver', $src ) : '';
}


/* ═══════════════════════════════════════════════════════════════════════════
   5. DIVI TWEAKS
   ═══════════════════════════════════════════════════════════════════════════ */

// Replace Divi's viewport tag with one that allows zooming.
if ( $o['fix_divi_viewport'] ) {
	add_action( 'wp_head', function () {
		remove_action( 'wp_head', 'et_add_viewport_meta' );
		echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">' . "\n";
	}, 1 );
}